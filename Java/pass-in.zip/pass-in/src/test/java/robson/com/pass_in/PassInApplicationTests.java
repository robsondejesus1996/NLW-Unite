package robson.com.pass_in;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassInApplicationTests {

	@Test
	void contextLoads() {
	}

}
